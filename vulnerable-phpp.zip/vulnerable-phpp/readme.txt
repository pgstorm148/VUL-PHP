 You are given two files also the connection and the database files are given to test the code. The given code is vulnerable to XSS and SQL Injection. Your task is to modify the given two files and fix the given two vulnerabilities (XSS and SQL Injection)

Note: You will only be allowed to submit once. Please submit all code once.

Code contains all the data, also, comments specify the working and solving of the question.

//Using prepared statement we can prevent sql injection and XSS attack
      //$query=mysqli_query($connection,"SELECT * FROM users WHERE username ='$uname' AND password ='$password'") or die("Query Unsuccessfull:".mysqli_error($connection));

      //$stmt -> affected_rows === 1
      